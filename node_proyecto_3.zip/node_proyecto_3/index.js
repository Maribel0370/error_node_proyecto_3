// Invocar los módulos
const express = require('express')
const app = express()

// Importamos el fihero con los datos
const customersJson = require('./data/customers.json')
console.log("7",typeof(customersJson))
console.log("ffhfggh");
// Definir el puerto de escucha
const PORT = 4000

// console.log(__dirname);


// Levantar la ruta HOME (raiz)
app.get('/', (req, res) => {
   //  res.send("<h1>Hola</h1>")
   res.sendFile('./public/index.html' , { root: __dirname})
})


// Levantar la ruta /clientes
app.get("/clientes" , (req, res) => {
    // mostramos un json
    res.json(customersJson)
})

app.get("/clientes/:nombre" , (req, res) => {

    // console.log(req.params.nombre);
    const nombre = req.params.nombre
    console.log(nombre)
    // const clientesFiltrados = customersJson.filter(customer => customer.name == nombre)
    for (let i = 0; i<customersJson.length; i++) {
        if (customersJson[i].name == nombre) {
            // res.json(customer);
            console.log(customersJson[i].name);
        }
    }
    // const clientesFiltrados = customersJson.filter(customer => console.log(customer.name))

    // console.log(clientesFiltrados)
    // // mostramos un json
    // res.json(clientesFiltrados);
})

app.use((req, res) => {
    res.status(404).sendFile('./public/404.html', { root: __dirname })
    // res.sendFile('./public/404.html' , { root: __dirname})
})


// Poner el servidor en escucha
app.listen(PORT, () => console.log(`Servidor en http://localhost:${PORT}`))